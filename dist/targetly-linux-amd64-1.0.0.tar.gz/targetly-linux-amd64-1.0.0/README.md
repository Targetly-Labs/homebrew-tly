# Dedalus MVP 1 – Architecture & Specification

This document outlines the complete MVP 1 design for **Dedalus** – a Vercel‑like hosting platform for MCP tools. It captures the agreed‑upon architecture, infrastructure, deployment lifecycle, container management, and developer experience based on our discussions.

---

## 🎯 Goal of MVP 1

Enable developers to:

```
npx dedalus deploy
```

And get:

* A **public MCP server URL**
* Hosted inside an **isolated Docker container** on your VPS
* Managed by Dedalus (start/stop)
* With **auto-idle shutdown** to conserve RAM

No secrets management. No LLM orchestration. No autoscaling. No SDK.

---

## 🧱 Core Components in MVP 1

### 1. **VPS Infrastructure**

The VPS hosts:

* API Server (Fastify / Node.js)
* Deployment Worker (Node.js)
* Docker Engine (for running MCP tools)
* Nginx Reverse Proxy
* Postgres (Dockerized)

### 2. **Hosted Postgres (Self‑Hosted on VPS)**

Dockerized Postgres with:

* Separate data directory
* Resource limits
* Daily cron backups
* Tuned memory for 8GB RAM

### 3. **File Storage**

Stored on VPS in:

```
/var/lib/dedalus/bundles
```

Used for deployment zip files.

### 4. **Reverse Proxy (Nginx)**

Each tool gets its own subdomain:

```
https://tool-123.dedalus.run
```

Dynamic Nginx configs:

```
server {
    server_name tool-123.dedalus.run;
    location / {
        proxy_pass http://127.0.0.1:<container_port>;
    }
}
```

### 5. **Docker Runtime**

Each deployed MCP tool runs as:

```
docker run -d \
  --name dedalus-<id> \
  --memory="512m" \
  --cpus="0.5" \
  -p <port>:8080 \
  dedalus-<id>
```

This ensures process isolation and prevents RAM starvation.

---

## 🚀 Deployment Flow

### **1. CLI Command**

```
npx dedalus deploy
```

* Zips current directory
* Sends project name + bundle to API

### **2. API Steps**

* Accepts bundle via multipart
* Stores it in `/var/lib/dedalus/bundles`
* Creates a `deployment` row in Postgres
* Pushes a job to BullMQ queue
* Responds with deployment ID

### **3. Worker Steps**

On job execution:

* Unzips bundle
* Builds Docker image
* Runs container with limits
* Assigns a random internal port
* Generates Nginx config
* Reloads Nginx
* Updates DB with URL + status

### **4. Output to User**

```
Your tool is deployed:
https://tool-123.dedalus.run
```

---

## 🧩 Database Schema (MVP 1)

### **deployments**

```
id SERIAL PRIMARY KEY
project_name TEXT
status TEXT                -- running | sleeping | error
bundle_path TEXT
container_name TEXT
container_port INT
public_url TEXT
last_accessed_at TIMESTAMP   -- For idle shutdown
created_at TIMESTAMP
updated_at TIMESTAMP
```

### **users** (minimal)

```
id SERIAL PRIMARY KEY
email TEXT
created_at TIMESTAMP
```

### **projects**

```
id SERIAL PRIMARY KEY
user_id INT
name TEXT
created_at TIMESTAMP
```

---

## 🔥 Idle Shutdown (Critical for VPS Stability)

To prevent RAM exhaustion, containers are auto‑stopped when idle.

### **Tracked per deployment:**

```
last_accessed_at
```

### **Nginx logs update this timestamp on every request**

Each MCP request updates access time.

### **Reaper Script (Cron, runs every 5 min)**

Logic:

* Fetch all deployments
* If `NOW - last_accessed_at > 15 min`:

  * `docker stop container`
  * update DB: `status = 'sleeping'`

### **No auto‑wake in MVP 1**

Stopped containers return JSON:

```
{"error": "Tool is sleeping. Run `dedalus start <id>` to resume."}
```

---

## 🛠 Manual Resume (MVP 1)

Users can restart containers without redeploying.

### CLI

```
dedalus start tool-123
```

### API

```
POST /deployments/:id/start
```

Runs:

```
docker start dedalus-<id>
```

And updates DB:

```
status = 'running'
```

---

## 🔐 VPS Disk, Memory & Safety

### **8GB RAM Safe Capacity**

* Baseline system: ~1.2GB
* Free: ~6.8GB
* Containers: 8–12 concurrently

### **Docker Log Limits (critical)**

```
/etc/docker/daemon.json
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "50m",
    "max-file": "3"
  }
}
```

Prevents disk blow‑up.

### **Postgres Memory Tune**

```
shared_buffers = 256MB
effective_cache_size = 512MB
work_mem = 8MB
maintenance_work_mem = 64MB
max_connections = 50
```

---

## 📦 Folder Structure (VPS)

```
/var/lib/dedalus/
    postgres/            # DB data
    bundles/             # Upload zips
    logs/                # Nginx + app logs
    build-contexts/      # Temporary Docker builds

/opt/dedalus/
    api/
    worker/
    reaper/
```

---

## 🧭 MVP 1 Out of Scope

To ship quickly:

* No autoscaling
* No auto-wake
* No secrets management
* No model selection
* No orchestration SDK
* No tool marketplace

These come in MVP 2+.

---

## 🏁 Summary

Dedalus MVP 1 focuses entirely on the **core developer experience**:

* Deploy MCP tools with one command
* Auto-host them on VPS
* Isolated containers with controlled resources
* Clean subdomain routing
* Idle shutdown to protect your server
* Easy manual resume

This is lean, fast, and stable enough to onboard your first **50–200 developers**.

---

Let me know when you're ready for the next doc:

* **MVP 2 design** (auto-wake + secrets)
* **CLI spec**
* **API contract document**
* **Worker implementation details**

# Targetly MVP 1 – Feature & Command Overview

This section defines **all features**, **CLI commands**, and **functional expectations** for Targetly MVP 1. It is meant as a concise, actionable product + engineering specification.

---

## 🎯 MVP 1 – Primary Objective

Enable developers to deploy MCP tools to the cloud with a single command:

```
tly deploy
```

Targetly will:

* Build a Docker image from the provided code
* Run it in an isolated container on your VPS
* Expose it via a unique subdomain
* Auto-shutdown idle containers to conserve resources
* Allow manual start/resume without redeploying

---

## 🧱 MVP 1 – Feature List (Complete)

### ✅ 1. **Project Deployment**

* Developers run `tly deploy`
* Code is zipped + uploaded
* Targetly builds and runs it as a Docker container
* Assigns a subdomain: `https://tool-<id>.targetly.com`
* Saves deployment metadata in Postgres

### ✅ 2. **Container Hosting & Proxying**

* Nginx reverse proxy routes requests to correct container port
* Each deployment gets isolated resource-limited Docker runtime

### ✅ 3. **Idle Shutdown (Mandatory for VPS stability)**

* Track `last_accessed_at` on every request
* Reaper script stops containers idle > 15 minutes
* Containers become `sleeping`

### ✅ 4. **Manual Resume (No redeploy required)**

Developers start their container with:

```
tly start <deployment-id>
```

* Container wakes instantly
* Continues with same URL & data

### ✅ 5. **Status & Logs**

* View container status (running / sleeping / error)
* Download or stream logs (tail of local file)

### ✅ 6. **Basic User & Project Management**

* Lightweight auth (email only or token-based)
* Project name stored with deployments

### ⚠️ Out of Scope for MVP 1

* No secret storage
* No environment variables
* No auto-wake on traffic
* No autoscaling or multi-region
* No orchestration SDK
* No marketplace

---

## 🛠️ CLI Specification (MVP 1)

CLI name: **tly** (Targetly CLI)

### ### **1. `tly login`**

Authenticate user with API.

### ### **2. `tly deploy`**

Primary command.

* Zips current directory
* Sends bundle + project name
* API returns deployment URL

Output example:

```
Deploying to Targetly...
✔ Build complete
✔ Container running
Your tool is live at: https://tool-123.targetly.com
```

### ### **3. `tly start <deployment-id>`**

Wake a sleeping deployment.

```
tly start tool-123
```

### ### **4. `tly status <deployment-id>`**

Shows container state, port, last access time.

### ### **5. `tly logs <deployment-id>`**

Fetch tail logs.

### ### **6. `tly init`** (Optional, good DX)

Creates a skeleton MCP project folder.

---

## 🧩 API Endpoints (MVP 1)

### **POST /deploy**

Upload zip → queue worker → return deployment ID.

### **GET /deployments/:id**

Return:

```
status, url, port, last_accessed_at
```

### **POST /deployments/:id/start**

Start existing container.

### **GET /logs/:id**

Return text logs.

---

## 🗄️ Database Schema (Condensed)

### deployments

```
id SERIAL
project_name TEXT
status TEXT
bundle_path TEXT
container_name TEXT
container_port INT
public_url TEXT
last_accessed_at TIMESTAMP
created_at TIMESTAMP
updated_at TIMESTAMP
```

### users

Minimal auth.

### projects

Optional grouping.

---

## 🧠 System Behavior Summary

### **Deploy**

→ upload → build → run → route → done.

### **Idle Shutdown**

* Nginx logs traffic
* Cron checks idle > 15 mins
* container stops
* DB marked sleeping

### **Resume**

```
tly start <id>
```

* container starts instantly

### **No Redeploy Needed**

This is a key Targetly MVP advantage.

---

## 📦 Infrastructure Summary

### VPS runs:

* API server
* Worker
* Nginx
* Docker engine
* Dockerized Postgres

### Safety:

* Docker memory limits
* Postgres memory tuning
* Disk management & log caps
* Daily backups

---

## 🏁 MVP 1 Completion Checklist

### Engineering

* [ ] CLI (tly) operational
* [ ] API: deploy, start, status, logs
* [ ] Worker builds + runs containers
* [ ] Nginx dynamic routing
* [ ] Idle shutdown reaper done
* [ ] Postgres schema + migrations
* [ ] Docker log + memory limits set
* [ ] Deploy + resume flow tested

### Developer Experience

* [ ] Clear error for sleeping tools
* [ ] Pretty CLI output
* [ ] Quickstart guide
* [ ] Example MCP project to test

### Launch

* [ ] targetly.com landing page
* [ ] Documentation page
* [ ] Early access signup
* [ ] Announce to dev communities

---

This concludes the key MVP 1 feature and command documentation. Let me know if you want this expanded into:

* a product requirements document (PRD)
* a technical architecture diagram
* a public-facing docs version
* or a roadmap for MVP 2.
